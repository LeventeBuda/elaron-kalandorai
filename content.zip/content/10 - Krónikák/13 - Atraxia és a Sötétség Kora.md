
## II. A Sötétség Felemelkedése (Atraxia Rémuralma)
Ez a korszak Valtoris történetének legsötétebb fejezete. Atraxia, a Lélekfaló megjelenése egy évszázadokig tartó rémálmot hozott a kontinensre.

## Atraxia, a Lélekfaló
Atraxia, a Lélekfaló egy rendkívüli tehetséggel megáldott, de romlott szívű mágus volt, aki felfedezte, hogyan nyerhet hatalmat mások életerejéből. Uralma alatt a mágia a "lélekfalás" szinonimájává vált. Városokat igázott le, és lakóikat mágikus rabszolgaságban tartotta, energiájukat saját élete és hatalma meghosszabbítására használva.

## A Rémuralom Évei
Ebben az időszakban a klasszikus mágiaiskolák elpusztultak. Csak a sötét művészetek virágoztak, a félelem pedig mindenki mindennapjait áthatotta. A birodalmi struktúrák összeomlottak, és csak a zsarnoknak behódoló kiskirályok maradhattak hatalmon.

## Az Összefogás Ára
A korszak végén a birodalmak maradékai – félretéve ősi ellentéteiket – szövetséget kötöttek. Egy hatalmas háború árán sikerült legyőzni Atraxıát, de a győzelem keserű volt: a kontinens romokban hevert, a mágia forrásai beszennyeződtek vagy kiapadtak, és az emberek örökre meggyűlölték a varázshasználókat.

