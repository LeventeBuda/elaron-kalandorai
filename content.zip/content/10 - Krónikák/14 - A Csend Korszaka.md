
## III. A Rend Korszaka (A Csend és a Megtagadás)

Atraxia bukását követően a világ egy olyan korszakba lépett, ahol a mágia nemkívánatos, sőt, üldözött dologgá vált. Ezt az időszakot a technológiai fejlődés és a mágia szinte teljes hiánya jellemezte.

## A Mágia Megtagadása
A háború után a birodalmak szigorú törvényeket hoztak: a varázslást halállal vagy száműzetéssel büntették. A legtöbb mágikus tekercset elégették, a rúnákat lekaparták a falakról, és a varázstárgyakat megsemmisítették. Az emberiség kollektíven próbálta elfelejteni azt az erőt, amely majdnem a pusztulásukat okozta.

## A Technológia és a Fizikai Erő Felemelkedése
Mivel a mágia már nem segítette az építkezést vagy a harcot, a népek a mérnöki tudományok és a fizikai edzettség felé fordultak. Ebben a korban fejlődtek ki a legmodernebb ostromgépek, a kohászat és a bonyolult óramű-szerkezetek. A lovagi rendek és a nehézgyalogság vált a hadviselés alapjává.

## A Rend Fenntartása
A hit és a katonai fegyelem lett a társadalom tartóoszlopa. Létrejöttek az Inkvizíciók és a Tisztasági Őrségek, melyek feladata az volt, hogy felkutassák és elfojtsák a mágia legkisebb szikráját is. A világ csendes volt, kiszámítható és mágikus értelemben üres.