
## Valtoris Történelme
Valtoris krónikái négy nagy korszakra oszthatók. Minden korszakváltást egy drasztikus változás jelzett a mágia jelenlétében és a társadalmi berendezkedésben.

## I. Az Alapítás Kora
A civilizáció hajnala, a mágia és a tudomány harmonikus együttélése. Ebben a korban rakták le az alapjait azoknak a birodalmaknak, amelyek ma is meghatározzák a kontinenst.

## II. A Sötétség Felemelkedése (Atraxia Rémuralma)
A zsarnokság korszaka, amikor a mágia a pusztítás és az elnyomás eszközévé vált. Ez a korszak mély sebeket hagyott a népek kollektív emlékezetében, és megalapozta a mágiától való félelmet.

## III. A Rend Korszaka (A Csend és a Megtagadás)
A technológia és a fizikai erő korszaka. A mágia szinte teljes eltűnése után a világ megtanult varázslat nélkül létezni, szigorú törvényekkel tiltva minden misztikus tevékenységet.

## IV. Az Új Ébredés (A Kapuk és az Ismeretlen Visszatérése)
A jelenkor, amely a Hasadékok megjelenésével vette kezdetét. A mágia kaotikus formában tért vissza, kényszerítve a birodalmakat, hogy újragondolják mindazt, amit a világról hittek.