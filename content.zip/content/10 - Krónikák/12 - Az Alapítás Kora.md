
## I. Az Alapítás Kora
Az Alapítás Kora a bőség és a felfedezés időszaka volt. A történészek szerint ez volt az egyetlen korszak, amikor a mágia természetes és tiszta forrásként volt jelen Valtorisban.

## A Mágia Aranykora
A korai telepesek nem félték a mágiát, hanem eszközként használták. Az épületeket rúnák tartották össze, a termést bűbájok segítették, és a távolsági kommunikáció is megoldott volt. A tudás közkincs volt, és a nagy könyvtárak nyitva álltak mindenki előtt.

## A Birodalmak Születése
Ebben a korban jöttek létre az első nagy királyságok. A határok még képlékenyek voltak, a hangsúly a terjeszkedésen és az ismeretlen területek feltérképezésén volt. Nem léteztek még a mai értelemben vett zárt Céhek, a tudás átadása mesterek és tanítványok között, szabadon zajlott.

## A Korszak Vége
Az aranykornak a hatalomvágy és a sötét kísérletek vetettek véget, amelyek utat nyitottak Atraxia felemelkedésének. A mágia túlzott és felelőtlen használata végül egy olyan alak kezébe adott fegyvert, aki az egész világot romlásba döntötte.