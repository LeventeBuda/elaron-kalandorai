
## Sylvander Politikája

Az ősi erdők birodalma, amely Valtoris éléskamrájaként funkcionál. Elszigetelt, de megkerülhetetlen szereplő a kontinens túlélése szempontjából.

## Fő Kereskedelmi Árucikkek
- **Fa és Étel:** A nemes épületfa és a bőséges gabona- és gyümölcstermés adja Sylvander erejét. Ők látják el Karádorn gyári munkásait és Skarnheim harcosait élelemmel.

## Diplomáciai irányelvek
- **Gazdasági Pajzs:** A tündék és erdei emberek tudják, hogy az ételimport leállítása bárkit térdre kényszerít, ezért ezt használják diplomáciai fegyverként a területüket fenyegető bányászat ellen.
- **Morvund:** Kifejezetten veszélyesnek tartják. A morvundi gyógynövényeket "természetellenesnek" bélyegzik és gyanakodva figyelik a mocsár terjeszkedését.

## Belpolitika
A **Természet Tanácsa** és az **Öregek** vezetik a népet. A döntéshozatal lassú és megfontolt, a cél mindig a hosszú távú egyensúly fenntartása a civilizáció és az élővilág között. A hierarchia alapja a természettel való spirituális kapcsolat mélysége.