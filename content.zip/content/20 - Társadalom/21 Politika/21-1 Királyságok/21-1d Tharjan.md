
## Tharjan Politikája

Az aranyló dűnék és obszervatóriumok birodalma. Tharjan a semlegességét nem karddal, hanem elmével és információval védi.

## Fő Kereskedelmi Árucikkek
- **Tudás és Információ:** Tharjan elméleti megoldásokat, tervrajzokat és csillagászati adatokat exportál. Ők a kontinens akadémiai központja.

## Diplomáciai irányelvek
- **Mágia-prioritás:** Az Új Ébredés óta minden diplomáciai lépésüket a mágia megértése vezérli. 
- **Semlegesség:** Mindenki számára nyitottak, aki fizet a tudásért vagy hozzájárul a kutatásokhoz. Morvund alvilági kapcsolatait is hajlandók kihasználni, ha az egy ritka irat megszerzését jelenti.

## Belpolitika
A birodalmat a **Főtanács (A Tanultak Gyülekezete)** irányítja. Náluk nincs örökletes nemesség; a társadalmi ranglétrán való emelkedés záloga a tudományos fokozat és a sikeres felfedezések. A városok vezetése a rektorok és tudósok feladata.