
## Harcos Céh (A Rend és a Penge)

A Harcos Céh a hivatásos katonák, veterán zsoldoskapitányok és a városi rendfenntartók gyűjtőhelye. Feladatuk a civilizáció védelme, a határok sérthetetlensége és a belső rend fenntartása acéllal és fegyelemmel.

## Városi Rendfenntartás és Polgári Biztonság
A legtöbb birodalomban a Harcos Céh látja el a városi őrség feladatait. Nem csupán katonák, hanem rendfenntartók is:
- **Járőrözés és Közrend:** Ők felelnek a piacok, a kikötők és a lakónegyedek nyugalmáért. Bármilyen fegyveres konfliktust vagy bűncselekményt vaskézzel fojtanak el.
- **Kalandor-felügyelet:** Különös figyelmet fordítanak a kalandorok által látogatott negyedekre és fogadókra. A városi őrség szemében minden kalandor potenciális bajforrás, ezért a legkisebb kihágásért is súlyos büntetéseket vagy az Engedély ideiglenes bevonását alkalmazzák.
- **Kapuk és Vámok:** A városfalaknál és a Hasadék-zónák bejáratainál ők ellenőrzik a vámokat és a papírokat, biztosítva, hogy illegális mágikus tár
- **Hasadék-lezárás:** Amint egy új Hasadékot észlelnek, a Harcos Céh egységei vonulnak ki elsőként, hogy fizikai kordont vonjanak köré. Céljuk a terület teljes lezárása, hogy csak hivatásos Kalandorok mehessenek be.