## Kereskedő Céh (Az Arany és a Logisztika Urai)

A kontinens gazdasági hálóját ők tartják kézben. Karádorn acéljától kezdve Sylvander gabonáján át Morvund gyógynövényeiig minden az ő szekereiken és hajóikon mozog.

## Politikai Befolyás
A Kereskedő Céh gyakran erősebb, mint egy-egy kisebb nemesi udvar. Ők finanszírozzák a legtöbb kalandor-expedíciót, cserébe az ott talált kincsek elsővételi jogáért. Számukra a Hasadék egy új, rendkívül jövedelmező piac, és mindent megtesznek, hogy a kristálykereskedelem ne csússzon ki a kezükből.