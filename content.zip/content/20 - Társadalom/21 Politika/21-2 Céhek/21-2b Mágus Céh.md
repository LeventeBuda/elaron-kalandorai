
## Mágus Céh (A Tudomány és Misztikum Fúziója)

A Csend Korszaka alatt a Mágus Céh szinte teljesen beolvadt az akadémiai és alkímiai társaságokba. Az Új Ébredéssel azonban ismét az élvonalba kerültek, mint a Hasadék-energia egyetlen szakértői.

## Működési Elv
A céh vallja, hogy a mágia nem varázslat, hanem egy ismeretlen fizikai törvényszerűség. Tagjaik között éppúgy megtalálhatók a régi könyvtárakat bújó krónikások, mint a modern laboratóriumokban dolgozó kristály-analitikusok.

## Kapcsolat a Kalandorokkal
A Mágus Céh a legnagyobb "fogyasztója" a kalandorok által hozott áruknak. Ők tartják fenn a kristály-bevizsgáló állomásokat, és ők készítik a kalandorok számára a speciális védőfelszereléseket az anomáliák ellen.